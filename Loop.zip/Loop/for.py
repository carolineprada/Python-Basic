# -*- coding: utf-8 -*-
"""
Created on Wed Aug 11 22:34:04 2021

@author: Caroline
"""

A=[1,2,3]

for a in A:

  print(2*a)
  
  x=5
while(x!=2):
  print(x)
  x=x-1

for i,x in enumerate(['A','B','C']):
    print(i,2*x)