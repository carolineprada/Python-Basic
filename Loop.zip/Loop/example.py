# -*- coding: utf-8 -*-
"""
Created on Wed Aug 11 09:02:34 2021

@author: Caroline
"""


for x in range(0,3):
     print(x)


for y in ['A','B','C']:

  print(y+'A')
  
  
for i,z in enumerate(['A','B','C']):
    print(i,z)  
    
    